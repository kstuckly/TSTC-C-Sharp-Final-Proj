﻿IF OBJECT_ID('dbo.Party', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Party]
 END
;
IF OBJECT_ID('dbo.Party', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Party] 
    (
      [Party_Id] NUMERIC(5,0) NOT NULL,
	  [Party_Code] NVarChar(20) NOT NULL,
      [Name] NVarChar(100) NOT NULL,
      [Address] NVarChar(100),
      [City] NVarChar(100),
      [State] NVarChar(100),
      [Zip] NVarChar(5),
      [Phone] NVarChar(20),
      [Fax] NVarChar(20),
      [Region] NVarChar(20),
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL,
	  primary key ([Party_ID], [Party_Code])
    ) 
  END
  ;
IF OBJECT_ID('dbo.Party_History', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Party_History]
 END
;
IF OBJECT_ID('dbo.Party_History', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Party_History] 
    (
      [Party_Id] NUMERIC(5,0) NOT NULL,
	  [Party_Code] NVarChar(20) NOT NULL,
	  [Party_SeqNo] INTEGER NOT NULL,
      [Name] NVarChar(100) NOT NULL,
      [Address] NVarChar(100),
      [City] NVarChar(100),
      [State] NVarChar(100),
      [Zip] NVarChar(5),
      [Phone] NVarChar(20),
      [Fax] NVarChar(20),
      [Region] NVarChar(20),   
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL,
      [Deleted_Ind] NVarChar(1) NOT NULL,
	  primary key ([Party_ID], [Party_Code], [Party_SeqNo])
    ) 
  END
  ;
IF OBJECT_ID('dbo.Code', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Code]
 END
;
IF OBJECT_ID('dbo.Code', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Code] 
    (
      [ID] NUMERIC(5,0) NOT NULL, 
      [Type] NVarChar(15) NOT NULL, 
      [Description] NVarChar(50) NOT NULL,
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL,
      [Deleted_Ind] NVarChar(1) NOT NULL,
	  primary key ([ID], [Type])
    ) 
  END
  ;
IF OBJECT_ID('dbo.Product', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Product]
 END
;
IF OBJECT_ID('dbo.Product', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Product] 
    (
	  [Product_ID] NUMERIC(7,0) NOT NULL,
	  [Name] NVarChar(50),
	  [Description]	NVarChar(250),
	  [Weight] Numeric(5,2),
	  [Vendor_ID] Numeric(5,0),
	  [Unit_Price] Numeric(7,2),
	  [Product_Image] NVarChar(200),
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL
	  primary key ([Product_ID])
    ) 
  END
  ;
  IF OBJECT_ID('dbo.Product_History', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Product_History]
 END
;
IF OBJECT_ID('dbo.Product_History', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Product_History] 
    (
	  [Product_ID] NUMERIC(7,0) NOT NULL,
	  [Product_SeqNo] INTEGER NOT NULL,
	  [Name] NVarChar(50),
	  [Description]	NVarChar(250),
	  [Weight] Numeric(5,2),
	  [Vendor_ID] Numeric(5,0),
	  [Unit_Price] Numeric(7,2),
	  [Product_Image] NVarChar(200),
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL,
      [Deleted_Ind] NVarChar(1) NOT NULL,
	  primary key ([Product_ID] ASC, [Product_SeqNo] ASC) 
    ) 
  END
  ;
IF OBJECT_ID('dbo.Product_Vendor', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Product_Vendor]
 END
;
IF OBJECT_ID('dbo.Product_Vendor', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Product_Vendor] 
    (
	  [Product_ID] NUMERIC(7,0) NOT NULL,
      [Vendor_ID] NUMERIC(5,0) NOT NULL,
      [Unit_Price] NUMERIC(7,3),
      [Dlvd Price] NUMERIC(7,2),
      [Begin_Date] Date,
      [End_Date] Date,
      [Last_Update] DateTime NOT NULL,
      [Last_Activity] NVarChar(1) NOT NULL,
      [Deleted_Ind] NVarChar(1) NOT NULL,
	  primary key ([Product_ID], [Vendor_ID])
    ) 
  END
  ;
IF OBJECT_ID('dbo.Order_Hdr', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Order_Hdr]
 END
;
IF OBJECT_ID('dbo.Order_Hdr', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Order_Hdr] 
    (
	  [Order_Nbr] NUMERIC(7,0) NOT NULL,
      [Order_Store_Vendor_Nbr] Numeric(7,0),	
      [Order_Date] Date,
	  [Order_Type] NVarchar(10),	
      [Order_Status] NVarchar(15),
	  [Name] NVarchar(40),
	  [Address] NVarchar(40),
	  [City] NVarchar(40),
	  [State] NVarchar(2),
	  [Zip] NVarchar(8),
	  [Phone] NVarchar(15),
      [Total] Numeric(10,2) Default 0.00,	
      [Last_Update]	Date NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  primary key ([Order_Nbr])
	)
 End
 ;
 IF OBJECT_ID('dbo.Order_Hdr_History', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Order_Hdr_History]
 END
;
IF OBJECT_ID('dbo.Order_Hdr_History', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Order_Hdr_History] 
    (
	  [Order_Nbr] NUMERIC(7,0) NOT NULL,
	  [Order_SeqNo] INTEGER NOT NULL,
      [Order_Store_Vendor_Nbr] Numeric(7,0),	
      [Order_Date] Date,
	  [Order_Type] NVarchar(10),	
      [Order_Status] NVarchar(15),
	  [Name] NVarchar(40),
	  [Address] NVarchar(40),
	  [City] NVarchar(40),
	  [State] NVarchar(2),
	  [Zip] NVarchar(8),
	  [Phone] NVarchar(15),
      [Total] Numeric(10,2) default 0.00,	
      [Last_Update]	Date NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  [Deleted_Ind] NVarchar(1),
	  primary key ([Order_Nbr], [Order_SeqNo])
	)
 End
 ;
IF OBJECT_ID('dbo.Order_Dtl', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Order_Dtl]
 END
;
IF OBJECT_ID('dbo.Order_Dtl', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Order_Dtl] 
    (
	  [Order_Nbr] NUMERIC(7,0) NOT NULL,
      [Product_ID] NUMERIC(7,0) NOT NULL,	
      [Description] NVarchar(35),
      [Order_Qty] Numeric(9,0),	
      [Unit_Price] NUMERIC(18,3),	
      [Extended_Amt] NUMERIC(25,2) default 0.00,	
      [Last_Update]	Date NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  primary key ([Order_Nbr], [Product_ID])
	)
 End
 ;
 IF OBJECT_ID('dbo.Order_Dtl_History', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Order_Dtl_History]
 END
;
IF OBJECT_ID('dbo.Order_Dtl_History', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Order_Dtl_History] 
    (
	  [Order_Nbr] NUMERIC(7,0) NOT NULL,
	  [Order_SeqNo] INTEGER NOT NULL,
      [Product_ID] NUMERIC(7,0) NOT NULL,	
      [Description] NVarchar(35),
      [Order_Qty] Numeric(9,0),	
      [Unit_Price] NUMERIC(18,3),	
      [Extended_Amt] NUMERIC(25,2) default 0.00,	
      [Last_Update]	Date NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  [Deleted_Ind] NVarchar(1),
	  primary key ([Order_Nbr], [Order_SeqNo], [Product_ID])
	)
 End
 ;
IF OBJECT_ID('dbo.Warehouse', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Warehouse]
 END
;
IF OBJECT_ID('dbo.Warehouse', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Warehouse] 
    (
      [Product_ID] Numeric(7,0) NOT NULL,	
      [Product_Name] NVarchar(50),
      [Location] Nvarchar(50) NOT NULL,
      [QTY_Available] NUMERIC(8,0),	
      [QTY_On_Order] NUMERIC(8,0),	
      [Min_Order_Qty] NUMERIC(8,0),	
      [Last_Update]	Date NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  primary key ([Product_ID])
	)
 End
 ;
IF OBJECT_ID('dbo.Warehouse_History', 'U') IS NOT NULL 
 BEGIN 
    DROP TABLE [dbo].[Warehouse_History]
 END
;
IF OBJECT_ID('dbo.Warehouse_History', 'U') IS NULL 
 BEGIN 
   CREATE TABLE [dbo].[Warehouse_History] 
    (
      [Product_ID] NUMERIC(7,0) NOT NULL,
      [Sequence_No] INTEGER NOT NULL,
      [Transaction_ID] NVarchar(20) NOT NULL,
      [Transaction_Date] DateTime,	
      [Transaction_Type] NVarchar(20),
	  [Product_Name] NVarchar(50),
	  [Location] Nvarchar(50) NOT NULL,
      [Qty_Available] NUMERIC(8,0) default 0,
	  [Qty_On_Order] NUMERIC(8,0) default 0,
	  [Min_Order_Qty] NUMERIC(8,0) default 0,	
      [Qty_Shipped] NUMERIC(8,0) default 0,	
      [Qty_Received] NUMERIC(8,0) default 0,	
      [Qty_Available_Current] NUMERIC(10,0) default 0,	
      [Last_Update]	DateTime NOT NULL,	
      [Last_Activity] NVarchar(1) NOT NULL,
	  [Deleted_Ind] NVarchar(1),
	  primary key ([Product_ID] ASC, [Sequence_No] ASC)
	)
 End
 ;


Select [Order_Nbr],
       ISNULL([Order_Store_Vendor_Nbr], 0) 'Order_Store_Vendor_Nbr',
       ISNULL([Order_Date], ''),
       ISNULL([Order_Type], ''),
       ISNULL([Order_Status], '') 'Order_Status',
       ISNULL([Name], ''),
       ISNULL([Address], ''),
       ISNULL([City], ''),
       ISNULL([State], ''),
       ISNULL([Zip], ''), 
       ISNULL([Phone], '')
       From [dbo].[Order_Hdr]
       Where [Order_Type] = 'VNDR'
       Order by [Order_Nbr] ASC;


