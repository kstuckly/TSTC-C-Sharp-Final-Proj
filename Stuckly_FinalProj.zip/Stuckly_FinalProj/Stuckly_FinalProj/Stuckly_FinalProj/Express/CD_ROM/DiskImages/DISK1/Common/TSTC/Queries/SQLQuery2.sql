﻿SELECT 
[Product_ID],
[Name],
[Description],
[Weight],
[Height],
[Length],
[Width],
[Product_Image],
[Product_URL]
FROM dbo.product
WHERE [Deleted_Ind] IS NULL
ORDER BY [Product_ID];



Select ISNULL(Max(Sequence_No), 0)
From [dbo].[Warehouse_History] 
WHERE [Product_ID] = 


select * from dbo.Warehouse_History