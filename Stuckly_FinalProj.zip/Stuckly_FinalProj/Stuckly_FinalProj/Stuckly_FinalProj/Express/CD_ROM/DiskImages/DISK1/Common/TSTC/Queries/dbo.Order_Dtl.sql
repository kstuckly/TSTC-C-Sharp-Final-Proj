﻿CREATE TABLE [dbo].[Order_Dtl] (
    [Order_Nbr]     NUMERIC (7)     NOT NULL,
    [Product_ID]    NUMERIC (7)     NOT NULL,
    [Description]   NVARCHAR (35)   NULL,
    [Order_Qty]     NUMERIC (6)     NULL,
    [Unit_Price]    NUMERIC (12, 3) NULL,
    [Extended_Amt]  NUMERIC (18, 2) DEFAULT ((0.00)) NULL,
    [Last_Update]   DATE            NOT NULL,
    [Last_Activity] NVARCHAR (1)    NOT NULL,
    PRIMARY KEY CLUSTERED ([Order_Nbr] ASC, [Product_ID] ASC)
);
